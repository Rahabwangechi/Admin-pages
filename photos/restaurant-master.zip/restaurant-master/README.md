# restaurant

## Mama Fish Restaurant

This is A basic Restaurant website still under developement. Currently its implemented with HTML and CSS. Javascript and yet to be determined backend language will be used later to allow customer to achieve the following: 
1. reserve a table
2. order food within the website.
3. Comment on cuisines
4. Mark cuisine as favorite.
5. Send Feedback.
